fateme abedini
assignment for embedded inteligence

